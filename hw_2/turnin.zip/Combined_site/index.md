
<!DOCTYPE html>
    <html>
    <html lang="en">
      <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <body style="background-color:powderblue;">

        <title>About me</title>

      </head>
      <body>
        <!-- Grey with black text -->

        <nav class="navbar navbar-expand-sm bg-dark navbar-dark navbar-static-top">
          <ul class="navbar-nav ">
            <li class="nav-item active">
              <a class="nav-link" href="href="index.html"">Home</a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="projects.html">Projects</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="form.html">Bootstrap_Form</a>
        </li>
          <ul class="navbar-nav mr-auto  ">
          <li class="nav-item">
            <a class="navbar-brand  " href="https://github.com/Shadedstrike">
          <img src="https://cdn.discordapp.com/attachments/719339765777825822/761301913593053184/empty.png" alt="Logo" style="width:40px;">

      </a>

        </ul>
        </nav>

        <div class="container ">
        <h1>Ott, April</h1>
        </div>
        <div class="container bg-dark black">

        <div class="card bg-info text-black">
        <div class="card-body">Hello, I'm April, a Computer Science major at CU Boulder. I'm facinated with how code interacts with every aspect of our lives. I especially am interested in automation, as I feel that through automation, we can replace mundane tasks in society, and free up people's time.</div>
      </div>


      </body>
      <div class="container bg-dark text-white">
      <header>
        <h2>My professional profile:</h2>
         &nbsp;
        <img src="https://cdn.discordapp.com/attachments/719339765777825822/761283192107171880/P_20200707_135304_1_1.jpg" class="rounded" alt="Here's a image of space! >" height="366px" width="360px">
      </header>

      <header>
        <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
        th, td {
          padding: 5px;
          padding-top: .5em;
          padding-bottom: .5em;

        }
        </style>
         &nbsp;
        <h3>My favorite projects:</h3>

                <table style="width:100%">

                  <tr>
                    <th>Project name</th>
                    <th>Tech utilized</th>
                  </tr>
                  <tr>
                    <td>Vibify</td>
                    <td>NodeJS, React, SQL</td>
                  </tr>
                  <tr>
                    <td>Creating a loadable kernal module</td>
                    <td>C and C++</td>
                  </tr>
                  <tr>
                    <td>This website</th>
                    <td>HTML + CSS</td>
                  </tr>
                  </table>
      </header>
      &nbsp;


      <button type="button" class="btn btn-primary active float-right">Add interest</button>




      <h3>
      <p>My interests:</p>
    </h3>
    <div class="card-deck">
      <div class="card">
        <img class="card-img-top" src="https://cdn.pixabay.com/photo/2016/08/12/05/06/technology-1587673__340.jpg" alt="Card image cap">
        <div class="card-body text-dark ">
          <h5 class="card-title">Back-end automation</h5>
          <p class="card-text">As a Linux systems administrator, I ensure that infrastrucure is running at tip top shape.</p>
        </div>
      </div>
      <div class="card">
        <img class="card-img-top" src="https://cdn.discordapp.com/attachments/719339765777825822/761319055461842944/coonstruct.png" alt="Card image cap">
        <div class="card-body text-dark">
          <h5 class="card-title">Front-end engineering</h5>
          <p class="card-text">As a web developer, I enjoy making interactive websites .</p>
        </div>
      </div>
      <div class="card">
        <img class="card-img-top" src="https://cdn.discordapp.com/attachments/719339765777825822/761320009678061568/codeeeee.png" alt="Card image cap">
        <div class="card-body text-dark">
          <h5 class="card-title">Assorted programming</h5>
          <p class="card-text">I enjoy working with C++, JS, Python and Ruby.</p>
        </div>
      </div>
    </div>
      </div>

      <!-- Footer -->
      <footer class="page-footer font-small blue">

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">
          <a href="https://www.linkedin.com/in/april-ott-b8a3491b8/">
         <img alt="linkedin" src="https://www.fpsa.org/wp-content/uploads/linkedin-logo-copy.png" height="40px" width="40px">
      </a>
        </div>
        <!-- Copyright -->

      </footer>
      <!-- Footer -->
    </html>
